#!/usr/bin/env python3
# console.py — 统一入口：shim 接口控制台（Web 版，stdlib http.server，无三方依赖）。
# 启动时自动 ensure（bridge.shimctl 编译 + 注入 shim 到 Wine 里的 TdxW.exe，若未在线），再起服务。
# 非入口的支撑代码都在包里：bridge/（消息桥）、mem/（读内存方案）。
#
# 启动：python3 scripts/console.py [port]      默认 8765
# 浏览器：http://127.0.0.1:8765
#
# 提供的 API：
#   GET  /                                   控制台页面
#   GET  /api/ping                           {pid}（离线为 null）
#   GET  /api/treewatch                      SSE：shim treewatch 原样转发（窗口树版本号）
#   GET  /api/gdiwatch                       SSE：shim gdiwatch 原样转发（窗口绘制层）
#   GET  /api/positions                      读内存持仓表（含完整性校验）
#   GET  /api/slippage                       持仓 × 5 档盘口滑点表（需 pytdx）
#   POST /api/shim            {cmd,args}     透传 shim 命令，回 JSON 记录列表（命令表见 shim.c）
#   POST /api/clicktext {text,class?,title?} 点可见窗口上画着 text 的按钮（须唯一）
#   POST /api/refresh                        点交易栏「刷新」让客户端刷新持仓
# 任何失败（assert 等）统一回 {err}。

import os
import sys
import json
import time
import types
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from bridge.shimctl import Shim, ensure  # noqa: E402  消息桥（编译/注入/控制通道）
from mem import positions as mempos  # noqa: E402  内存持仓方案（含完整性校验）

HTML_FILE = os.path.join(HERE, "console.html")
REFRESH_BTN = {"class": "MHPToolBar", "title": "MainViewBar", "text": "刷新"}
SHIM = Shim()


# ---------- 按绘制文字点按钮 ----------


def click_text(b):
    """在 class/title（给了才比）匹配的可见窗口的绘制层里找文字恰为 text 的项，
    向该窗口投递其中心点的左键单击（自绘控件谁画谁处理点击）。须唯一命中。"""
    want = {k: b[k] for k in ("class", "title") if b.get(k)}
    wins = {
        n["hwnd"]: n
        for n in SHIM("tree")
        if n["vis"] and all(n[k] == v for k, v in want.items())
    }
    hits = [
        (wins[d["hwnd"]], d["off"], it)
        for d in SHIM("gdidump")
        if d["hwnd"] in wins
        for it in d["items"]
        if len(it) > 5 and it[5].strip() == b["text"]
    ]
    assert len(hits) == 1, f"{b} 命中 {len(hits)} 处，需唯一（加 class/title）"
    n, off, (l, t, r, bt, *_) = hits[0]
    x = n["rect"][0] + off[0] + (l + r) // 2
    y = n["rect"][1] + off[1] + (t + bt) // 2
    return SHIM("clickat", n["hwnd"], x, y)


# ---------- 刷新持仓 ----------


def refresh(b):
    """点交易栏「刷新」让客户端刷新持仓，等明文落堆后返回。"""
    click_text(REFRESH_BTN)
    time.sleep(0.8)  # 等客户端完成查询、明文落堆
    return {}


# ---------- 滑点（持仓 × 5 档盘口，相对参考价）----------
# 方向即符号 s：买 +1 吃卖盘、价位往上；卖 -1 吃买盘、价位往下。
# 滑点与价位两组列同构：(量, s)，滑点乘 s → 正=成本。只出数字，格式化归前端。

SLIP_HOSTS = [
    ("115.238.90.165", 7709),
    ("124.71.187.122", 7709),
    ("114.141.177.121", 7709),
    ("182.131.3.227", 7709),
]
BUY, SELL = +1, -1
BOOK = {BUY: "ask", SELL: "bid"}
NOTIONALS = (10000, 50000, 100000)  # 吃 n 元
PCTS = (1, 2)  # 偏 p%
SLIP_COLS = [(n, s) for n in NOTIONALS for s in BOOK]
LEVEL_COLS = [(p, s) for p in PCTS for s in BOOK]
GROUPS = {
    "green": {
        "600697",
        "301006",
        "300535",
        "605567",
        "603214",
        "600561",
        "300645",
        "301037",
    },
    "red": set(),
}


def _grp(code):
    return next((g for g, codes in GROUPS.items() if code in codes), "")


def _book(q, s):
    """方向 s 吃的那侧 5 档 [(价, 股)]，略去空档。"""
    side = BOOK[s]
    levels = [
        (q[f"{side}{i}"], q[f"{side}_vol{i}"] * 100) for i in range(1, 6)
    ]  # 手→股
    return [(p, v) for p, v in levels if p > 0 and v > 0]


def _micro(q):
    """卖一/买一按对手量加权；任一侧空盘回 None。"""
    ask, bid = _book(q, BUY), _book(q, SELL)
    if not ask or not bid:
        return None
    (a, av), (b, bv) = ask[0], bid[0]
    return (a * bv + b * av) / (av + bv)


def _ref(q):
    """参考价：micro price → 现价 → 昨收，取首个可用；都没有回 None。"""
    return _micro(q) or next((x for x in (q["price"], q["last_close"]) if x > 0), None)


def _fill(book, notional):
    """按档吃 notional 元 → (均价, 是否吃满)。"""
    spent = shares = 0.0
    for price, vol in book:
        take = min(vol, (notional - spent) / price)
        spent += take * price
        shares += take
        if spent >= notional - 1e-6:
            break
    return (spent / shares if shares else None), spent >= notional - 1e-6


def _slip(q, ref, n, s):
    """吃 n 元均价相对 ref 的万分比 × s（正=成本）；full=5 档吃满，否则实际更差。"""
    avg, full = _fill(_book(q, s), n)
    return {"pct": s * (avg - ref) / ref * 1e4 if avg else None, "full": full}


def _level(ref, p, s):
    """ref 朝方向 s 偏 p% 的价位。"""
    return ref * (1 + s * p / 100)


def _row(pos, q, weight):
    """一只持仓：各列滑点 + 各列价位；无行情或无参考价时两组皆 None。"""
    ref = _ref(q) if q else None
    return {
        "code": pos["code"],
        "name": pos["name"],
        "group": _grp(pos["code"]),
        "weight": weight,
        "slips": [_slip(q, ref, n, s) for n, s in SLIP_COLS] if ref else None,
        "levels": [_level(ref, p, s) for p, s in LEVEL_COLS] if ref else None,
    }


def _agg(rows, i):
    """第 i 列滑点按市值占比加权。"""
    pairs = [
        (r["slips"][i]["pct"], r["weight"])
        for r in rows
        if r["slips"] and r["slips"][i]["pct"] is not None and r["weight"] > 0
    ]
    den = sum(w for _, w in pairs)
    return sum(v * w for v, w in pairs) / den if den else None


def compute_slippage():
    """读持仓 → 批量取 5 档 → 每只各列滑点 + 各列价位 + 市值占比；市值加权 aggregate。"""
    from pytdx.hq import TdxHq_API

    positions = mempos.read()["positions"]
    assert positions, "无持仓（先刷新，或在客户端点一次持仓查询）"
    api = TdxHq_API()
    assert any(api.connect(h, p) for h, p in SLIP_HOSTS), "连不上行情服务器 7709"
    quotes = api.get_security_quotes([(p["market_flag"], p["code"]) for p in positions])
    api.disconnect()
    assert quotes is not None, "取 5 档盘口失败"
    qmap = {(q["market"], q["code"]): q for q in quotes}
    total = sum(p["market_value"] or 0 for p in positions) or 1
    rows = [
        _row(
            p, qmap.get((p["market_flag"], p["code"])), (p["market_value"] or 0) / total
        )
        for p in positions
    ]
    return {
        "slip_cols": SLIP_COLS,
        "level_cols": LEVEL_COLS,
        "agg": [_agg(rows, i) for i in range(len(SLIP_COLS))],
        "rows": rows,
    }


# ---------- 路由 ----------
# 处理函数一律 fn(body) → 应答；应答类型决定载体：str=页面、生成器=SSE、其余=JSON。

GET = {
    "/": lambda b: open(HTML_FILE, encoding="utf-8").read(),
    "/api/ping": lambda b: {"pid": SHIM("ping")[0]["pid"] if SHIM.online() else None},
    "/api/treewatch": lambda b: SHIM.lines("treewatch"),
    "/api/gdiwatch": lambda b: SHIM.lines("gdiwatch"),
    "/api/positions": lambda b: mempos.read(),
    "/api/slippage": lambda b: compute_slippage(),
}

POST = {
    "/api/shim": lambda b: SHIM(b["cmd"], *b["args"]),
    "/api/clicktext": click_text,
    "/api/refresh": refresh,
}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass  # 静默

    def handle_one_request(self):
        # SSE 长连接，浏览器刷新/关页会中途断连，sendall 撞 BrokenPipe；属正常，静默。
        try:
            super().handle_one_request()
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True

    def do_GET(self):
        self._route(GET, {})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        self._route(POST, json.loads(self.rfile.read(n)) if n else {})

    def _route(self, table, b):
        try:
            body = table[self.path](b)
        except Exception as e:  # 唯一错误边界：任何失败都回 {err} 给前端显示
            body = {"err": f"{type(e).__name__}: {e}"}
        if isinstance(body, str):
            self._send("text/html; charset=utf-8", body.encode())
        elif isinstance(body, types.GeneratorType):
            self._stream(body)
        else:
            self._send(
                "application/json; charset=utf-8",
                json.dumps(body, ensure_ascii=False).encode(),
            )

    def _send(self, ctype, data):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _stream(self, gen):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        with closing(gen):
            for x in gen:
                self.wfile.write(f"data: {x}\n\n".encode())
                self.wfile.flush()


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    ensure()  # 编译 + 注入 shim（若未在线），统一入口一条命令搞定
    # noraise 不抬窗：重扫模块，补钩 shim 注入后才加载的 DLL
    # gdi 绘制层：自绘按钮的文字/色块（首次装入口钩子并重绘全部窗口）
    for cmd in ("noraise", "gdi"):
        r = SHIM(cmd, "on")
        assert r[-1]["on"] and not any("skip" in x for x in r), f"{cmd} on: {r}"
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"[*] 控制台: http://127.0.0.1:{port}  (Ctrl+C 退出)")
    srv.serve_forever()


if __name__ == "__main__":
    main()
