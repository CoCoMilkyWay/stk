#!/usr/bin/env python3
# mem/positions — 内存方案：持仓明文表（customize，非通用基建）。
# 客户端点过一次「持仓查询」后，解密明文驻留堆里。表头锚点 0||28||P00，
# 其后每行一只持仓：\r\n 分行、| 分列、行首 6 位代码、GBK 编码。
# 两种列布局：≥22 列完整视图 / 18 列精简视图（重登后常见），列序见 COLS。
#
# 完整性（读内存最大的坑是读到写入中途的坏块）：
#   1) scan 全量定位一次，再按址只复读该块，连读两次字节一致才采信（common.stable）；
#   2) validate 做结构校验：代码 6 位、列布局全表一致、沪深标志合法、
#      无 GBK 替换字符、且「市值 ≈ 现价 × 余额」交叉验证列没错位。
# 任一校验不过直接 assert（早失败，宁可不给数也不给错数）。

import re

from . import common

HEADER = b"0||28||P00"
ROW = rb"\d{6}\|(?:[^|\r\n]*\|){4}[^\r\n]*\r\n"  # 6 位代码 + 至少 5 个 |
BLOCK_RE = re.compile(re.escape(HEADER) + rb"[^\r\n]*\r\n(?:" + ROW + rb")+")
SLACK = 64 * 1024  # 复读窗口在块尾外多留的字节，容块在两次读之间长大


def _num(x):
    return float(x) if x else None


# 字段 → (转型, 完整视图列号, 精简视图列号)
FULL, COMPACT = 1, 2
# fmt: off
COLS = {
    "code":         (str,  0,  0),
    "name":         (str,  1,  1),
    "balance":      (_num, 3,  3),
    "available":    (_num, 4,  4),
    "cost":         (_num, 8,  7),
    "price":        (_num, 9,  8),
    "market_value": (_num, 10, 9),
    "pnl":          (_num, 11, 10),
    "pnl_pct":      (_num, 12, 11),
    "market_flag":  (int,  14, 13),
    "shareholder":  (str,  19, 15),
}
# fmt: on


def _blocks(lo, data):
    """data（起址 lo）里每个表头起的整块 → (表头地址, 块)。find 定位表头，正则只在锚点处匹配。"""
    ho = data.find(HEADER)
    while ho != -1:
        m = BLOCK_RE.match(data, ho)
        if m:
            yield lo + ho, m.group()
        ho = data.find(HEADER, ho + 1)


def _locate(pid):
    """全量扫一遍，取行数最多的块 → 复读窗口 (表头地址, 窗口尾)；没有回 None。窗口不越段尾。"""
    hits = (
        (addr, min(lo + len(data), addr + len(b) + SLACK), b.count(b"\r\n"))
        for lo, data in common.iter_regions(pid)
        for addr, b in _blocks(lo, data)
    )
    hit = max(hits, key=lambda h: h[2], default=None)
    return hit and hit[:2]


def _reread(pid, addr, end):
    """按址复读窗口，在表头处重新匹配整块；块已不在回 None。"""
    m = BLOCK_RE.match(common.read_at(pid, addr, end - addr))
    return m and m.group()


def scan(pid):
    """取持仓明文块，带完整性：全量定位一次，再按址只复读该块，连读两次一致才采信。"""
    common.ensure_access()
    win = _locate(pid)
    return win and common.stable(lambda: _reread(pid, *win))


def _position(f):
    """一行字段 → 持仓；按列数选布局，按 COLS 取列转型。"""
    at = FULL if len(f) >= 22 else COMPACT
    assert len(f) > max(
        c[at] for c in COLS.values()
    ), f"{f[0]} 仅 {len(f)} 列，不认识的布局"
    p = {k: c[0](f[c[at]]) for k, c in COLS.items()}
    p["nf"] = len(f)
    return p


def parse(block):
    """解析明文块 → 持仓列表；每行附 nf（列数）供 validate 判断布局一致性。
    块由 BLOCK_RE 保证：首行表头，其后全是持仓行。"""
    lines = block.decode("gbk", errors="replace").split("\r\n")[1:-1]
    return [_position(ln.split("|")) for ln in lines]


def validate(positions, block):
    """结构完整性校验，任一不满足即 assert（早失败，拒绝给错数）。"""
    assert positions, "持仓为空（块里没有效行）"
    assert "\ufffd" not in block.decode(
        "gbk", errors="replace"
    ), "明文含 GBK 替换字符，疑似读到写入中途的坏块"
    layouts = {p["nf"] for p in positions}
    assert len(layouts) == 1, f"行列数不一致 {layouts}，块可能被截断/串行"
    for p in positions:
        assert re.fullmatch(r"\d{6}", p["code"]), f"非法代码 {p['code']!r}"
        assert p["name"], f"{p['code']} 名称为空"
        assert p["market_flag"] in (
            0,
            1,
        ), f"{p['code']} 沪深标志异常 {p['market_flag']}"
        mv, price, bal = p["market_value"], p["price"], p["balance"]
        if mv and price and bal and price > 0:  # 停牌价为 0 时跳过
            exp = price * bal
            assert abs(exp - mv) <= max(
                1.0, exp * 0.02
            ), f"{p['code']} 市值({mv})≠现价×余额({exp:.2f})，数值列疑似错位"


def totals(positions):
    """市值 / 浮盈合计。"""
    mv = sum(p["market_value"] or 0 for p in positions)
    pnl = sum(p["pnl"] or 0 for p in positions)
    return {"market_value": round(mv, 2), "pnl": round(pnl, 2)}


def read(pid=None):
    """方案入口：定位进程 → 扫块(完整性) → 解析 → 校验 → {pid, positions, totals}。
    块不存在（没点过查询）时返回空列表，不算错误。"""
    pid = pid or common.find_tdxw_pid()
    assert pid, "找不到 tdxw.exe 进程"
    block = scan(pid)
    if not block:
        return {"pid": pid, "positions": [], "totals": totals([])}
    positions = parse(block)
    validate(positions, block)
    return {"pid": pid, "positions": positions, "totals": totals(positions)}
